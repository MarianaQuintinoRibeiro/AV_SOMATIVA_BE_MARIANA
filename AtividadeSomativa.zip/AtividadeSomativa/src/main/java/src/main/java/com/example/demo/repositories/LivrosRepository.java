package src.main.java.com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import src.main.java.com.example.demo.entities.Livros;

public interface LivrosRepository extends JpaRepository<Livros, Long>{

	//Query Methods
			List<Livros> buscarPorTitulo(String titulo);
			Livros findById(String id);
	
}
