package src.main.java.com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import src.main.java.com.example.demo.entities.Autor;
import src.main.java.com.example.demo.entities.Livros;
import src.main.java.com.example.demo.repositories.AutorRepository;

@Service
public class AutorService {
	
	@Autowired
	private AutorRepository autorRepository;

	public List<Autor> getAllAutores() {
		return autorRepository.findAll();
	}

	public Autor getAutorById(long autcodigo) {
		return autorRepository.findById(autcodigo).orElse(null);
	}

	public Autor saveAutor(Autor autor) {
		return autorRepository.save(autor);
	}
	
	public void deleteAutor(Long id) {
    	autorRepository.deleteById(id);
    }
	
	 //query buscar por titulo service
    public List<Autor> buscarPorNome (String nome) {
    	return autorRepository.buscarPorNome(nome);
    }
    
    public List<Autor> buscarPorPais (String pais) {
    	return autorRepository.findByPais(pais);
    }

}
