package src.main.java.com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import src.main.java.com.example.demo.entities.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Long>{

}
