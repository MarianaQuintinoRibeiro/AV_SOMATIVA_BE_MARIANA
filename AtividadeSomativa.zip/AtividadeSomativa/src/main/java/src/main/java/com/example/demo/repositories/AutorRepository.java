package src.main.java.com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import src.main.java.com.example.demo.entities.Autor;

public interface AutorRepository extends JpaRepository<Autor, Long>{

}
