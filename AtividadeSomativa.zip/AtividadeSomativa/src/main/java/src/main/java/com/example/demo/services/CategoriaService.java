package src.main.java.com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import src.main.java.com.example.demo.entities.Autor;
import src.main.java.com.example.demo.entities.Categoria;
import src.main.java.com.example.demo.repositories.CategoriaRepository;

@Service
public class CategoriaService {
	
	@Autowired
	private CategoriaRepository categoriaRepository;

	public List<Categoria> getAllCategorias() {
		return categoriaRepository.findAll();
	}

	public Categoria getCategoriaById(long catcodigo) {
		return categoriaRepository.findById(catcodigo).orElse(null);
	}

	public Categoria saveCategoria(Categoria categoria) {
		return categoriaRepository.save(categoria);
	}
	
	public void deleteCategoria(Long id) {
    	categoriaRepository.deleteById(id);
    }
	
	 //query buscar por titulo service
    public List<Categoria> buscarPorNome (String nome) {
    	return categoriaRepository.buscarPorNome(nome);
    }
    
    public List<Categoria> buscarPorDescricao (String descricao) {
    	return categoriaRepository.findByDescricao(descricao);
    }

}
