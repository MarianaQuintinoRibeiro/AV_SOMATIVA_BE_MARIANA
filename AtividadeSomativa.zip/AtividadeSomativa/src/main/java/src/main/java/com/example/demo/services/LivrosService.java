package src.main.java.com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import src.main.java.com.example.demo.entities.Livros;
import src.main.java.com.example.demo.repositories.LivrosRepository;

@Service
public class LivrosService {
	
	@Autowired
	private LivrosRepository livrosRepository;
	
	public Livros saveLivros(Livros livros) {
		return livrosRepository.save(livros);
	}

	public Livros getLivrosById(long livcodigo) {
		return livrosRepository.findById(livcodigo).orElse(null);
	}
	
	public List<Livros> getAllLivros() {
		return livrosRepository.findAll();
	}
	
	public void deleteLivro(Long id) {
    	livrosRepository.deleteById(id);
    }
	
	 //query buscar por titulo service
    public List<Livros> buscarPorTitulo (String titulo) {
    	return livrosRepository.buscarPorTitulo(titulo);
    }
    
    public List<Livros> buscarPorAno (String ano) {
    	return livrosRepository.findByAno(ano);
    }
    
    public List<Livros> buscarPorAutor (String autor) {
    	return livrosRepository.findByAutor(autor);
    }
    
    public List<Livros> buscarPorCategoria (String categoria) {
    	return livrosRepository.findByCategoria(categoria);
    }
    

}
